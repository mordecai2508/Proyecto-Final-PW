<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="Styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Inicio de Sesion</title>
</head>
<body>
      <div class="left">
        <form action="login.php" method="POST">
            <h1>Iniciar Sesion</h1>
            <hr>
            <?php
                if (isset($_GET['error'])) {
                    ?>
                    <p class="error">
                        <?php
                            echo $_GET['error']
                        ?>
                    </p>
            <?php
                }
            ?>


            <hr>
            <i class="fa-solid fa-user"></i>
            <label>Usuario</label>
            <input type="text" name="Usuario" placeholder="Nombre de usuario">

            <i class="fa-solid fa-unlock"></i>
            <label>Contraseña</label>
            <input type="text" name="Clave" placeholder="Contraseña">
            <hr>

            <button type="submit">Iniciar Sesion     <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#e8eaed"><rect fill="none" height="24" width="24"/><path d="M14.59,7.41L18.17,11H6v2h12.17l-3.59,3.59L16,18l6-6l-6-6L14.59,7.41z M2,6v12h2V6H2z"/></svg></button>
            <a class="text-white" href="register.php" >Crear Cuenta</a>
            <a class="text-white " href="recuperarC.php">Recuperar contraseña</a>
        </form>
      </div>
      <div class="right">
        
      <img src="imgs/S1000RR.png" class="rounded float-left">
      </div>
    
    
</body>
</html>