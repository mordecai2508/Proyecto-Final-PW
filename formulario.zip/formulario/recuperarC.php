<?php  
session_start();
include('connection.php');

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $Usuario = validate($_POST['Usuario']);
    
    $Sql = "SELECT * FROM usertbl WHERE username = ?";

    $stmt = mysqli_prepare($conn, $Sql);
    mysqli_stmt_bind_param($stmt, "s", $Usuario);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        $mensaje = "La contraseña del usuario es: " . htmlspecialchars($row["password"]);
    } else {
        $mensaje = "Usuario no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styles.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <title>Recuperar Contraseña</title>
</head>
<body>
<a href="index.php" class="btn btn-danger"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#e8eaed"><path d="M0 0h24v24H0z" fill="none"/><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>Regresar</a>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <h1>Recuperar Contraseña</h1>
        <p><i>Ingrese el usuario del cual desea recuperar la contraseña</i></p>
        <input type="text" name="Usuario" required>
        <input type="submit" value="Recuperar">
    </form>

    <div class="alert alert-info" role="alert">
        <?php echo $mensaje; ?>
    </div>
    
</body>
</html>
